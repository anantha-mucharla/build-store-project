import { queriesOfDashboard } from '../services/dashboard'
import tokenVerify from '../middleware/authen'
import express, { Request, Response } from 'express'


const dashboard = new queriesOfDashboard();

const categoryByProduct = productByCategoryfunc;

const orderByUserId =orderByUserIdfunc;

const mostPopularFiveProduct =mostPopularFiveProductfunc;

const orderCompletedByUserId =orderCompletedByUserIdfunc;

const rounteForDashboard =rounteForDashboardfunc;

function rounteForDashboardfunc(app: express.Application){
    app.get('/products-by-category', categoryByProduct)
    app.get('/complete-order-by-userid', tokenVerify, orderCompletedByUserId)
    app.get('/five-most-popular-product', mostPopularFiveProduct)
    app.get('/order-by-userid',tokenVerify, orderByUserId)
}


async function orderByUserIdfunc(_req:Request, res: Response){
    try{
    const orders = await dashboard.orderByUserId(_req.body.user_id);
    res.json(orders);
    }
    catch(err){
        res.status(400)
        res.json(err)
    }
}

async function orderCompletedByUserIdfunc (_req:Request, res: Response) {
    try{
    const orders = await dashboard.orderCompletedByUserId(_req.body.user_id);
    res.json(orders);
    }
    catch(err){
        res.status(400)
        res.json(err)
    }
}

async function productByCategoryfunc(_req:Request, res: Response) {
    try{
        const products = await dashboard.categoryByProduct(_req.body.category);
        res.json(products);
    }
    catch(err){
        res.status(400)
        res.json(err)
    }
}
async function orderCompletedByUserIdfunct (_req:Request, res: Response) {
    try{
    const orders = await dashboard.orderCompletedByUserId(_req.body.user_id);
    res.json(orders);
    }
    catch(err){
        res.status(400)
        res.json(err)
    }
}


async function mostPopularFiveProductfunc (_req:Request, res: Response){
    try{
    const products = await dashboard.mostPopularFiveProduct();
    res.json(products);
    }
    catch(err){
        res.status(400)
        res.json(err)
    }
}

export default rounteForDashboard