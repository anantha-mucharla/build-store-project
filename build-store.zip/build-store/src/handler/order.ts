import express, { Request, Response } from 'express'
import tokenVerify from '../middleware/authen'
import { createFunctionDeclaration } from 'typescript'
import { Order, OrderStore } from '../models/order'


const store = new OrderStore();

const create =createFunc;

const index =indexfunc;

const show =showfunc;

const addProduct =addProductfunc;

const  OrderRoutes=OrderRoutesfunc;
 
function OrderRoutesfunc(app: express.Application){
    app.post('/orders',tokenVerify, create)
    app.get('/orders', index)
    app.get('/orders/:id',tokenVerify, show)
    app.post('/orders/:id/products',tokenVerify, addProduct)
}

async function createFunc(_req: Request, res: Response){
    try {
        const order: Order = {
            status: _req.body.status,
            user_id: _req.body.user_id
        }
        const newOrder = await store.create(order)
        res.json(newOrder)
    } catch(err) {
        res.json(err)
    }
}

async function indexfunc (_req: Request, res: Response){
    try {
        const orders = await store.index()
        res.json(orders)
    } catch(err) {
        res.status(400)
        res.json(err)
    }
}
  

async function  showfunc(req: Request, res: Response){
    try {
        const order = await store.show(req.params.id)
        res.json(order)
    }catch(err) {
        res.status(400)
        res.json(err)
    }
}


async function addProductfunc (_req: Request, res: Response){
    const order_id: string = _req.params.id
    const product_id: string = _req.body.product_id
    const quantity: number = parseInt(_req.body.quantity)
  
    try {
      const addedProduct = await store.addProduct(quantity, order_id, product_id)
      res.json(addedProduct)
    } catch(err) {
      res.status(400)
      res.json(err)
    }
}

export default OrderRoutes;