import {Order, OrderStore} from '../../models/order';

const store = new OrderStore();

describe('Order model',describeFunc);
function  describeFunc(){
    it('should have index method', () => {
        expect(store.index).toBeDefined();
    })

    it('should have show method', () => {
        expect(store.show).toBeDefined();
    })

    it('should have create method', () => {
        expect(store.create).toBeDefined();
    })

    it('create method should add 1 order',createfunc);

    it('index method should return list',indexfunc);

    it('show method should return single order',showfunc);

    it('addProduct method should add 1 order_product',addproductfunc);

    
    async function indexfunc() {
        const result = await store.index();
        expect(result).toEqual([{
            id:1,
            status: 'active',
            user_id: '1'
        }])
    }

    async function createfunc(){
        const result = await store.create({
            status: 'active',
            user_id: '1'
        })
        expect(result).toEqual({
            id:1,
            status: 'active',
            user_id: '1'
        });
    }
    

    async function  addproductfunc(){
        const result = await store.addProduct(1, '1', '1');
        expect(result).toEqual({
            id:1,
            quantity:1, 
            product_id: '1', 
            order_id: '1'
        })
    }

    async function showfunc () {
        const result = await store.show('1');
        expect(result).toEqual({
            id:1,
            status: 'active',
            user_id: '1'
        })
    }
    
}